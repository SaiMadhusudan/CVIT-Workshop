# CVIT_workshop_medical
Template code and data for medical group, CVIT workshop
